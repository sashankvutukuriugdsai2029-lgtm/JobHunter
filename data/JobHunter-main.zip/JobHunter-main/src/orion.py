"""
Orion — Job-Contextual Q&A Co-pilot.
Provides conversational answers about a specific job utilizing the candidate's state and match score.
"""

from __future__ import annotations

import os

ORION_SYSTEM_PROMPT = """
You are Orion, a career co-pilot for a job seeker.
You have access to:
- The candidate's profile and skills
- A specific job description they're looking at  
- Their match score breakdown (overall, skills, experience, industry)
- Their application history and rejection patterns

Answer questions honestly and specifically. Examples:
- "Am I qualified?" → Use match score + missing skills
- "What's the culture like?" → Summarise from JD language and company signals
- "How should I prepare?" → Use detected patterns + missing skills
- "Should I apply?" → Weigh match score against their application strategy

Be direct. Don't hedge. If they're underqualified, say so and say why.
"""

def orion_chat(job: dict, candidate_state: dict, user_question: str) -> str:
    """Generate an Orion response for a specific job."""
    api_key = os.environ.get("GOOGLE_API_KEY", "").strip()
    if not api_key:
        return "Backend LLM key is not configured. Add GOOGLE_API_KEY to .env."

    try:
        from src.llm_factory import get_llm
        llm = get_llm(temperature=0.3)

        match_score = job.get("match_score", {})
        patterns = candidate_state.get("rejection_patterns", [])
        pattern_themes = [p.get("theme") for p in patterns]

        context = f"""
Job: {job.get('title')} at {job.get('company')}
Job Description snippet: {job.get('description', '')[:1000]}
Match Score: {match_score.get('overall', 0)}% ({match_score.get('match_label', 'Unknown')})
Missing Skills: {', '.join(match_score.get('missing_skills', []))}
Candidate Patterns/Weaknesses: {', '.join(pattern_themes) if pattern_themes else 'None'}
"""

        prompt = f"{ORION_SYSTEM_PROMPT}\n\nCandidate Context:\n{context}\n\nUser Question: {user_question}\n\nOrion:"
        response = llm.invoke(prompt)
        text = response.content if hasattr(response, "content") else str(response)
        return (text or "").strip()
    except Exception as exc:
        return f"Orion encountered an error: {exc}"
