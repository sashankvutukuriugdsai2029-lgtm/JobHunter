"""
Centralized LLM Factory for OpenRouter.
"""

from langchain_openai import ChatOpenAI
import os

# Fallback to provided key if not in env
DEFAULT_OPENROUTER_KEY = "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"

def get_llm(temperature: float = 0.2):
    """Return configured ChatOpenAI instance for OpenRouter."""
    api_key = os.environ.get("OPENROUTER_API_KEY", DEFAULT_OPENROUTER_KEY)
    
    return ChatOpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=api_key,
        model="liquid/lfm-2.5-1.2b-thinking:free",
        temperature=temperature,
        # Required for OpenRouter to track requests
        default_headers={
            "HTTP-Referer": "https://github.com/jobhunter",
            "X-Title": "JobHunter Copilot",
        }
    )
