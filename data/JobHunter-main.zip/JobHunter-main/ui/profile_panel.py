"""
Profile Panel - Renders candidate profile styled like RightJob.ai reference.
"""

from __future__ import annotations

import streamlit as st
from ui.components import render_skill_chips

def render_profile_panel(profile: dict):
    st.markdown('<div class="profile-page-bg">', unsafe_allow_html=True)
    
    # Header Banner
    st.markdown('''
    <div style="display:flex; align-items:center; background:#EAFCF5; padding:12px 16px; border-radius:8px; margin-bottom:24px;">
        <span style="font-size:16px; margin-right:8px;">🛡️</span>
        <span style="font-size:13px; color:#1A1A1A; font-weight:600;">Your profile data is kept private and secure. ❓</span>
    </div>
    ''', unsafe_allow_html=True)

    # Fake Tabs navigation
    st.markdown('''
    <div style="display:flex; gap:24px; border-bottom:1px solid #EAEAEA; margin-bottom:24px; padding-bottom:12px;">
        <div style="font-size:14px; font-weight:700; color:#1A1A1A; border-bottom:2px solid #1A1A1A; padding-bottom:10px; margin-bottom:-13px;">Personal</div>
        <div style="font-size:14px; font-weight:500; color:#8C8278;">Education</div>
        <div style="font-size:14px; font-weight:500; color:#8C8278;">Work Experience</div>
        <div style="font-size:14px; font-weight:500; color:#8C8278;">Skills</div>
        <div style="font-size:14px; font-weight:500; color:#8C8278;">Equal Employment</div>
    </div>
    ''', unsafe_allow_html=True)

    c_main, c_side = st.columns([2.5, 1], gap="large")

    with c_main:
        name = profile.get("name") or "Candidate"
        
        st.markdown(f'''
        <div class="profile-card">
            <div class="profile-name">{name} <span style="float:right; font-size:18px; color:#8C8278;">✎</span></div>
            <div>
                <div class="social-chip">✉️ candidate@example.com</div>
                <div class="social-chip">📞 +1 555-0100</div>
                <div class="social-chip">💼 linkedin.com/in/{name.lower().replace(" ", "")}</div>
                <div class="social-chip">🐙 github.com/{name.lower().replace(" ", "")}</div>
            </div>
        </div>
        ''', unsafe_allow_html=True)

        st.markdown('''
        <div class="profile-card">
            <div class="section-title">Education <span style="font-size:18px; color:#8C8278; font-weight:normal;">✎</span></div>
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-date">2021-09 ➔ 2025-05</div>
                    <div class="timeline-title">University of Technology</div>
                    <div class="timeline-subtitle">Bachelor of Science in Computer Science</div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-date">2017-09 ➔ 2021-05</div>
                    <div class="timeline-title">Green Valley High</div>
                    <div class="timeline-subtitle">High School Diploma</div>
                </div>
            </div>
        </div>
        ''', unsafe_allow_html=True)

        st.markdown('''
        <div class="profile-card">
            <div class="section-title">Work Experience <span style="font-size:18px; color:#8C8278; font-weight:normal;">✎</span></div>
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-date">2024-05 ➔ Present</div>
                    <div class="timeline-title">Software Engineering Intern</div>
                    <div class="timeline-subtitle">TechCorp Solutions</div>
                    <div class="timeline-content">
                        <ul>
                            <li>Developed RESTful APIs using Python and FastAPI, serving 10k+ daily requests.</li>
                            <li>Collaborated with the infrastructure team to migrate legacy services to Kubernetes.</li>
                            <li>Improved CI/CD pipeline efficiency by 30% utilizing GitHub Actions.</li>
                        </ul>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-date">2023-01 ➔ 2023-12</div>
                    <div class="timeline-title">Undergraduate Research Assistant</div>
                    <div class="timeline-subtitle">AI Lab, University of Technology</div>
                    <div class="timeline-content">
                        <ul>
                            <li>Assisted in training large language models for domain-specific question answering.</li>
                            <li>Pre-processed and cleaned datasets containing over 2 million text records.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        ''', unsafe_allow_html=True)

        skills = profile.get("base_skills", [])
        if not skills:
            skills = ["Python", "Java", "React", "Docker", "AWS", "SQL", "Git", "REST APIs", "CI/CD", "Machine Learning"]
            
        skills_html = render_skill_chips(skills)

        st.markdown(f'''
        <div class="profile-card">
            <div class="section-title">Skills <span style="font-size:18px; color:#8C8278; font-weight:normal;">✎</span></div>
            <div>{skills_html}</div>
        </div>
        ''', unsafe_allow_html=True)

        st.markdown('''
        <div class="profile-card">
            <div class="section-title">Equal Employment <span style="font-size:18px; color:#8C8278; font-weight:normal;">✎</span></div>
            <div style="font-size:13px; color:#5C534A; margin-bottom:12px;">Add your Employment history for better job matches tailored to your background</div>
            <div style="display:inline-flex; align-items:center; gap:8px; padding:8px 16px; border:1px solid #EAEAEA; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer;">
                <span>+</span> Employment
            </div>
        </div>
        ''', unsafe_allow_html=True)

    with c_side:
        st.markdown('''
        <div class="profile-alert">
            <div class="profile-alert-icon">!</div>
            <div class="profile-alert-text">
                <strong>Complete your profile to boost job matching accuracy and enable Autofill extension to autofill your applications.</strong>
            </div>
            <a href="#" class="profile-btn-black">Complete Profile</a>
        </div>
        
        <div class="profile-menu-item">
            <span>Manage My Resume</span>
            <span style="color:#8C8278;">›</span>
        </div>
        <div class="profile-menu-item">
            <span>Update LinkedIn URL</span>
            <span style="color:#8C8278;">›</span>
        </div>
        ''', unsafe_allow_html=True)
        
    st.markdown('</div>', unsafe_allow_html=True)
